Repository for XBMC/Kodi
==

•	Download: Repo/Repository.slashing/ current release

        https://github.com/slashing/kodi-brazzers/blob/master/repo/repository.slashing/repository.slashing-1.0.2.zip?raw=true
  
•	Install add-ons from zip file

•	Get Add-ons

•	Brazzers-addon-repository

•	Movie information

•	Install Brazzers-scraper


